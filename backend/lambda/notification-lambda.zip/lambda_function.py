import boto3
import json
import time

sns_client = boto3.client('sns')
sqs_client = boto3.client('sqs')

# Define your SQS Queue URL (Replace with your actual SQS queue URL)
SQS_QUEUE_URL = "https://sqs.us-east-1.amazonaws.com/841162702163/WelcomeMessageQueue"

def lambda_handler(event, context):
    for record in event['Records']:
        message_body = json.loads(record['body'])  # Extract message from SQS
        message_content = json.loads(message_body['Message'])  # Extract SNS message
        
        user_email = message_content['email']
        user_name = message_content['name']
        topic_name = user_name  # Create topic with username
       
        # 1. Create SNS Topic
        response = sns_client.create_topic(Name=topic_name)
        topic_arn = response['TopicArn']
        print(f"Created SNS topic: {topic_arn}")

        # 2. Subscribe User Email to the Topic
        subscription = sns_client.subscribe(
            TopicArn=topic_arn,
            Protocol="email",
            Endpoint=user_email
        )
        print(f"Subscription initiated for {user_email}. SubscriptionArn: {subscription['SubscriptionArn']}")

        # 3. Add message to SQS with a 2-minute delay
        delay_seconds = 120  # 2 minutes
        sqs_client.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps({
                "user_email": user_email,
                "user_name": user_name,
                "topic_arn": topic_arn
            }),
            DelaySeconds=delay_seconds
        )
        print(f"Welcome message scheduled for {user_email} in 2 minutes.")

    return {"statusCode": 200, "body": "Subscription process started successfully."}
