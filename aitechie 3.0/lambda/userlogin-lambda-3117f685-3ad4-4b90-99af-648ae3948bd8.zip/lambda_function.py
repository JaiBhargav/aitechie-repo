import json
import boto3
import hashlib

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('userdaat-table')  # Change to your actual DynamoDB table name

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        email = body.get('email')
        password = body.get('password')

        if not email or not password:
            return {
                "statusCode": 400,
                "headers": { "Access-Control-Allow-Origin": "*" },
                "body": json.dumps({"message": "Email and password are required"})
            }

        # Hash the input password (assuming stored passwords are hashed)
        hashed_password = password  # Update this if you use hashing

        # Scan the table to find the user by email
        response = table.scan(
            FilterExpression="email = :email",
            ExpressionAttributeValues={":email": email}
        )

        if 'Items' not in response or len(response['Items']) == 0:
            return {
                "statusCode": 401,
                "headers": { "Access-Control-Allow-Origin": "*" },
                "body": json.dumps({"message": "Invalid email or password"})
            }

        user = response['Items'][0]  # Get the first matching user

        # Check if password matches
        if user['password'] != hashed_password:
            return {
                "statusCode": 401,
                "headers": { "Access-Control-Allow-Origin": "*" },
                "body": json.dumps({"message": "Invalid email or password"})
            }

        # Return user_id along with login success message
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS, POST",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            "body": json.dumps({
                "message": "Login successful!",
                "user_id": user["userID"],  # Ensure 'userID' exists in DynamoDB
                "email": user["email"],
                "username":user["name"]
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": { "Access-Control-Allow-Origin": "*" },
            "body": json.dumps({"message": "Internal server error", "error": str(e)})
        }