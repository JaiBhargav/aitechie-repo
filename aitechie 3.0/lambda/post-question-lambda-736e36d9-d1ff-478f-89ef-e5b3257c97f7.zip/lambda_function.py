import json
import boto3
import uuid
import datetime

# Initialize DynamoDB
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("questions-table")  # Replace with your table name

def lambda_handler(event, context):
    try:
        # Parse request body
        body = json.loads(event["body"])
        question_title = body.get("title")
        userID = body.get("userID")

        if not question_title or not userID:
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Question title and userID are required"})
            }

        # Generate unique ID and timestamp
        question_id = str(uuid.uuid4())  # Unique ID for each question
        created_time = str(datetime.datetime.utcnow())  # Current UTC time

        # Store question in DynamoDB
        table.put_item(
            Item={
                "questionID": question_id,
                "userID": userID,
                "title": question_title,
                "createdTime": created_time  # Add created time
            }
        )

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",  
                "Access-Control-Allow-Methods": "OPTIONS, POST",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            "body": json.dumps({"message": "Question posted successfully!", "question_id": question_id})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Internal server error", "error": str(e)})
        }