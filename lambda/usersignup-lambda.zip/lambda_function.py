import json
import boto3
import uuid
import os

sns = boto3.client('sns')

SNS_TOPIC_ARN = os.environ['SNS_TOPIC_ARN']

def lambda_handler(event, context):
    try:
        print("Received event:", json.dumps(event))
        user_id = str(uuid.uuid4())
        # Parse event body
        if 'body' in event:
            body = json.loads(event['body'])
        else:
            body = event
        userID = user_id
        email = body.get('email')
        name = body.get('name')
        password = body.get('password')

        print("Extracted data:", email, name, password)

        if not email or not name or not password:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing required fields'})
            }

        # Publish message to SNS
        message = {
            "userID": userID,
            "email": email,
            "name": name,
            "password": password
        }

        print("Publishing message to SNS:", message)

        response = sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=json.dumps(message)
        )

        print("SNS Response:", response)

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",  # Allows cross-origin requests
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "POST"
            },
            "body": json.dumps({"message": "Account created successfully!"})  # Proper JSON response
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }