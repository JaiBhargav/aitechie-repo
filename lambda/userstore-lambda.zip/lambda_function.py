import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
TABLE_NAME = os.environ['DYNAMODB_TABLE']

def lambda_handler(event, context):
    try:
        print("Received event:", json.dumps(event))  # Log the entire event

        table = dynamodb.Table(TABLE_NAME)
        print(f"Using DynamoDB table: {TABLE_NAME}")  # Log the table name

        for record in event['Records']:
            # Parse the SNS notification
            sns_message = json.loads(record['body'])
            print("SNS Message:", sns_message)

            # Extract the actual message from the SNS notification
            message = json.loads(sns_message['Message'])
            print("Extracted message:", message)

            email = message.get('email')
            name = message.get('name')
            password = message.get('password')
            user_id = message.get('userID')

            if not email or not name or not password:
                print("Invalid message received:", message)
                continue

            # Store user in DynamoDB
            try:
                response = table.put_item(Item={
                    'name': name,
                    'email': email,
                    'password': password,
                    'userID': user_id
                })
                print(f"User {email} added successfully. Response: {response}")
            except Exception as e:
                print(f"Error adding user {email} to DynamoDB: {str(e)}")
                raise e

        return {'statusCode': 200, 'body': json.dumps({'message': 'Users processed successfully'})}

    except Exception as e:
        print("Error:", str(e))
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}