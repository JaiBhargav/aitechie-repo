import boto3
import json

sns_client = boto3.client('sns')

def lambda_handler(event, context):
    for record in event['Records']:
        message = json.loads(record['body'])
        
        user_email = message['user_email']
        user_name = message['user_name']
        topic_arn = message['topic_arn']

        try:
            response = sns_client.publish(
                TopicArn=topic_arn,
                Message=f"Welcome, {user_name}! Thank you for signing up.Start exploring and ask your first Question",
                Subject="Welcome to AItechie"
            )
            print(f"Welcome message sent successfully to {user_email}. Message ID: {response['MessageId']}")
        
        except Exception as e:
            print(f"Error sending welcome email to {user_email}: {str(e)}")
    
    return {"statusCode": 200, "body": "Welcome email sent successfully."}
