import json
import boto3
import uuid
from datetime import datetime

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("answers-table")  # Replace with your actual table name

def lambda_handler(event, context):
    try:
        # Parse the request body
        body = json.loads(event["body"])
        questionID = body.get("questionID")
        userID = body.get("userID")
        text = body.get("answer")

        # Validation
        if not questionID or not userID or not text:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing questionID, userID, or text"})
            }

        # Generate a unique ID for the answer
        answerID = str(uuid.uuid4())

        # Store the answer in DynamoDB
        table.put_item(
            Item={
                "answerID": answerID,
                "questionID": questionID,
                "userID": userID,
                "answer": text,
                "createdAt": (datetime.datetime.utcnow() + datetime.timedelta(hours=5, minutes=30)).isoformat()
            }
        )

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST"
            },
            "body": json.dumps({"message": "Answer submitted successfully!"})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
