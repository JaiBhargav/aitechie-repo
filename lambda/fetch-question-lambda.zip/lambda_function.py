import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource("dynamodb")
questions_table = dynamodb.Table("questions-table")  # Replace with your actual table name
userdata_table = dynamodb.Table("userdaat-table")  # Replace with your actual table name

# Function to convert DynamoDB Decimal values to float/int
def convert_decimal(obj):
    if isinstance(obj, list):
        return [convert_decimal(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_decimal(v) for k, v in obj.items()}
    elif isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)  # Convert to int if whole number, else float
    return obj

def lambda_handler(event, context):
    try:
        # Fetch all questions from the questions-table
        response = questions_table.scan()
        questions = response.get("Items", [])

        # Convert Decimal types before processing
        questions = convert_decimal(questions)

        # Fetch usernames from userdata-table for each question
        formatted_questions = []
        for question in questions:
            user_id = question.get("userID")
            created_time = question.get("createdTime") 
             # Fetch createdTime from questions-table

            # Fetch username from userdata-table using userID
            user_response = userdata_table.get_item(Key={"userID": user_id})
            user_data = user_response.get("Item", {})
            username = user_data.get("name", "Unknown")  # Default to "Unknown" if username is missing

            # Format the question data
            formatted_questions.append({
                "questionID": question.get("questionID"),
                "title": question.get("title"),
                "username": username,  # Include the username
                "createdTime": created_time  # Include the created time
            })

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET"
            },
            "body": json.dumps({"questions": formatted_questions})
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }