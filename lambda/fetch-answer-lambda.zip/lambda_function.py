import json
import boto3
from boto3.dynamodb.conditions import Attr

dynamodb = boto3.resource("dynamodb")
answers_table = dynamodb.Table("answers-table")  # Replace with your actual table name
users_table = dynamodb.Table("userdaat-table")  # Replace with your actual users table name

def lambda_handler(event, context):
    try:
        print("Received event:", json.dumps(event))  # Debugging log

        # Get the questionID from the query parameters
        question_id = event.get("queryStringParameters", {}).get("questionID")
        
        if not question_id:
            return {
                "statusCode": 400,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET",
                    "Access-Control-Allow-Headers": "Content-Type"
                },
                "body": json.dumps({"error": "Missing questionID parameter"})
            }

        # Scan the table for matching questionID
        response = answers_table.scan(
            FilterExpression=Attr("questionID").eq(question_id)
        )

        answers = response.get("Items", [])
        print("Fetched answers:", json.dumps(answers))  # Debugging log

        # Fetch usernames for each answer
        for answer in answers:
            user_id = answer.get("userID")
            if user_id:
                try:
                    user_response = users_table.scan(
                        FilterExpression=Attr("userID").eq(user_id)
                    )

                    # Extract user data
                    user_items = user_response.get("Items", [])
                    
                    if user_items:
                        answer["username"] = user_items[0].get("name", "Unknown User")
                    else:
                        answer["username"] = "Unknown User"

                except Exception as e:
                    print(f"Error fetching user {user_id}: {e}")
                    answer["username"] = "Unknown User"
            else:
                answer["username"] = "Anonymous"

        # Convert Decimal values to standard JSON
        for answer in answers:
            if "timestamp" in answer:
                answer["timestamp"] = int(answer["timestamp"])  # Convert timestamp to int

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({"answers": answers})
        }

    except Exception as e:
        print("Error:", str(e))  # Log the error
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({"error": str(e)})
        }
